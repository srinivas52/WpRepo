#!/bin/bash
yum -y install php > /var/log/installphp.out 2>&1

