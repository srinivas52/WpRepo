#!/bin/bash
service mysqld start > /var/log/startsql.out 2>&1

