#!/bin/bash
yum -y install mysql mysql-server > /var/log/installsql.out 2>&1

