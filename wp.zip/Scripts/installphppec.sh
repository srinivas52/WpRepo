#!/bin/bash
yum -y install php-pecl-apc > /var/log/installphppec.out 2>&1

